<!--
The user will see this page in case of error.
-->

<!DOCTYPE html>
<html>
<head>
    <title>My demo website</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h1>Error!</h1>
    <p>Payment was failed.</p>
</div>
</body>
</html>
